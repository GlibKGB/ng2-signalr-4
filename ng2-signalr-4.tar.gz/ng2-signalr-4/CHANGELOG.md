## Angular library starter Changelog

<a name="Mar 6, 2017"></a>
### Mar 6, 2017
* Add _compodoc_ for generating documentation 

<a name="Feb 5, 2017"></a>
### Feb 5, 2017
* Create library